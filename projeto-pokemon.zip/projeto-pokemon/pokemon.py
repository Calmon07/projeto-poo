from sqlalchemy import create_engine, Column, Integer, String, Float, ForeignKey
from sqlalchemy.orm import sessionmaker, declarative_base 

engine = create_engine('sqlite:///biblioteca.db')
Session = sessionmaker(bind=engine)
session = Session()

Base = declarative_base()

class Pokemon(Base):
    __tablename__ = "pokemons"  

    id_pokemon = Column("id", Integer, primary_key=True, autoincrement=True)
    hp = Column("hp", Integer)
    ataque = Column("ataque", Integer)
    velocidade = Column("velocidade", Integer)
    nivel = Column("nivel", Integer)
    exp = Column("exp", Float)
    tipo = Column("tipo", String)
    nome = Column("nome", String)
    regiao = Column("regiao", String)
    


    def __init__(self, id_pokemon, hp, ataque, velocidade, nivel, exp, tipo, nome, regiao):
           self.id_pokemon = id_pokemon
           self.hp = hp
           self.ataque = ataque
           self.velocidade = velocidade
           self.nivel = nivel
           self.exp = exp
           self.tipo = tipo
           self.nome = nome
           self.regiao = regiao
    
    #def atacar(self, )
          
Base.metadata.create_all(bind=engine)

listaPokemons = []

pokemon2 = Pokemon(2, 50, 12, 5, 12, 12.5, 'Água', 'Squirtle', 'Kanto')
pokemon3 = Pokemon(3, 30, 16, 10, 17, 10.5, 'Terra', 'Golem', 'Kanto')
pokemon4 = Pokemon(4, 35, 20, 17, 42, 20.5, 'Terra', 'Dugtrio', 'Kanto')
pokemon5 = Pokemon(5, 100, 5, 20, 62, 53.1, 'Pedra', 'Geodude', 'Kanto')
pokemon6 = Pokemon(6, 40, 21, 41, 76, 52.1, 'Elétrico', 'Pikachu', 'Kanto')

listaPokemons.append(pokemon2)


session.add(pokemon2)
session.commit()

print(listaPokemons)