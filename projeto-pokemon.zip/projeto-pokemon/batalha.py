import os

pergunta = int(input('O que você deseja fazer? '))

if pergunta == 1:
    pass
elif pergunta == 2:
    pass
