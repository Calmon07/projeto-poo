from pokemon_db import *

#Time do oponente
listaPokemonsOponente = []

#Times possíveis para o jogador
listaPokemonJogador1 = []
listaPokemonJogador2 = []
listaPokemonJogador3 = []

#Pokemons Oponente
pokemon1 = Pokemon(1, 'Bulbasaur', 30, 5, 20, 'Planta', 'Kanto')
pokemon2 = Pokemon(2, 'Charmander', 30, 5, 17, 'Fogo', 'Kanto')
pokemon3 = Pokemon(3, 'Squirtle', 30, 5, 15, 'Água', 'Kanto')

#Pokemons primeiro trio jogador
pokemon3
pokemon3
pokemon3

listaPokemonsOponente.append(pokemon1)
listaPokemonsOponente.append(pokemon2)
listaPokemonsOponente.append(pokemon3)

print(listaPokemonsOponente)

session.add(pokemon3)
session.commit()